from __future__ import annotations

import csv
import random
import sys
from dataclasses import replace
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from qlearn.agent import EpisodeStat, greedy_path, train  # noqa: E402
from qlearn.cli import build_parser, load, make_rng  # noqa: E402
from qlearn.env import Env  # noqa: E402
from qlearn.format import format_greedy_path, format_grid_policy, format_returns  # noqa: E402

WINDOW = 10
OPTIMAL_STEPS = 13
OPTIMAL_RETURN = -13.0


def moving_average(values: list[float], window: int = WINDOW) -> list[float]:
    out = []
    for i in range(len(values)):
        chunk = values[max(0, i - window + 1): i + 1]
        out.append(sum(chunk) / len(chunk))
    return out


def save_csv(path: Path, returns: list[float], stats: list[EpisodeStat]) -> None:
    mm = moving_average(returns)
    with path.open("w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["episodio", "recompensa", f"media_movil_{WINDOW}", "pasos", "caidas"])
        for i, (g, m, st) in enumerate(zip(returns, mm, stats), start=1):
            w.writerow([i, int(g), round(m, 2), st.steps, st.falls])


def plot_curve(path: Path, env: Env, returns: list[float]) -> bool:
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        print("(matplotlib is not installed: skipping the plot)")
        return False

    x = range(1, len(returns) + 1)
    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.plot(x, returns, color="tab:gray", alpha=0.4, linewidth=0.8, label="recompensa")
    ax.plot(x, moving_average(returns), color="tab:orange", linewidth=1.8,
            label=f"media móvil {WINDOW}")
    ax.axhline(OPTIMAL_RETURN, color="tab:green", linestyle=":", linewidth=1.2, label="-13")
    ax.set_ylim(-160, 0)
    ax.set_xlabel("episodio")
    ax.set_ylabel("recompensa")
    ax.set_title(f"Q-learning, cliff 4x12 (semilla {env.seed})")
    ax.grid(linestyle=":", alpha=0.5)
    ax.legend(loc="lower right")
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)
    return True


def robustness(env: Env, n: int) -> None:
    ok, others = 0, {}
    for seed in range(n):
        Q, _ = train(env, random.Random(seed))
        _, acts, G, done = greedy_path(env, Q)
        if done and len(acts) == OPTIMAL_STEPS and G == OPTIMAL_RETURN:
            ok += 1
        else:
            others[seed] = (len(acts), G)
    print(f"{ok}/{n} seeds give a greedy path of {OPTIMAL_STEPS} steps and return {OPTIMAL_RETURN:g}")
    if others:
        print("Seeds that do not (seed: (steps, return)):", others)


def main() -> None:
    parser = build_parser("Train Q-learning on the cliff and write the deliverables.")
    parser.add_argument(
        "--robustness", type=int, default=0, metavar="N",
        help="Only train with seeds 0..N-1 and count how many reach the optimal path",
    )
    args = parser.parse_args()
    env = load(args)
    env = replace(
        env,
        seed=args.seed if args.seed is not None else env.seed,
        episodes=args.episodes if args.episodes is not None else env.episodes,
        epsilon=args.epsilon if args.epsilon is not None else env.epsilon,
        alpha=args.alpha if args.alpha is not None else env.alpha,
        gamma=args.gamma if args.gamma is not None else env.gamma,
    )
    if args.robustness:
        robustness(env, args.robustness)
        return
    rng = make_rng(env, None)

    stats: list[EpisodeStat] = []
    Q, returns = train(env, rng, stats=stats)

    save_csv(ROOT / "recompensas_por_episodio.csv", returns, stats)
    plot_curve(ROOT / "curva_entrenamiento.png", env, returns)

    print(env.name)
    print(f"α = {env.alpha}    γ = {env.gamma:g}    ε = {env.epsilon}    "
          f"episodes = {env.episodes}    seed = {env.seed}")
    print()
    print("Greedy policy (arrows)")
    print("-" * 72)
    print(format_grid_policy(env, Q))
    print()
    print(format_greedy_path(env, Q))
    print()
    print("Training (ε-greedy on)")
    print("-" * 72)
    print(format_returns(returns, tail=100))
    print(f"episodes cut by max_steps = {env.max_steps}: {sum(1 for st in stats if not st.done)}")
    print(f"episodes with at least one fall: {sum(1 for st in stats if st.falls > 0)} of {len(stats)}")


if __name__ == "__main__":
    main()
