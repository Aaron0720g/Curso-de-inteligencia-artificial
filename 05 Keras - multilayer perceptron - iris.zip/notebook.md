- ¿Bajar más el error al añadir dos capas, o se estancó / empeoró? ¿Igual
     en NumPy y en Keras?
En el notebook 04 el resultado fue un estancamiento en las primeras 400 epocas, posterior a eso el modelo empezo a reducir su error, cabe reccalcar que la diferencia de error es minima; en el caso del notebook 05 al utilizar la funcion de entrenamiento sigmoid marcaba un error muy alto, a esto se implemento una estrategia de evaluar las primeras 3 capas con la funcion relu y la ultima en softmax, de esta manera el error fue de 0.08, mucho menor que con un modelo de densidad 2
   - ¿Las curvas de la notebook 01 y de Keras se parecen con la misma
     topología? Si no, ¿qué diferencias de implementación podrían explicarlo
     (orden de los datos, inicialización, vectorización, etc.)?
Visualmente no tienen la misma topologia, esto puede deberse a la asignacion de pesos aleatorios en el principio, esto puede hacer que reducir los costos y el error sea un problema y por ende se tengan que alcanzar un cierto numero de interwaciones elevado para que el modelo logre alcanzar a reducir el margen de error
   - Con sigmoides apiladas y MSE, ¿tiene sentido que una red **más profunda**
     no aprenda mejor en Iris? Relaciónalo con lo que viste en las gráficas.
Este es un tema que estabamos viendo en clase, ya que al parecer al integrar una red con mayor densidad evaluandola con la funcion sigmoide incrementaba el error